﻿function NumbersToNNot37(n) {
    for (var i = 1; i <= n; i++) {
        if (i % 21 != 0) console.log(i);
    }
}

var numberN = 134;
NumbersToNNot37(numberN);