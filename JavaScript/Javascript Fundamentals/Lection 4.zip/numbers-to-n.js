﻿function NumbersToN(n) {
    for (var i = 1; i <= n; i++) {
        console.log(i);
    }
}

var numberN = 34;
NumbersToN(numberN);