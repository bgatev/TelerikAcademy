﻿function DivCounter() {
    var result = document.getElementsByTagName("div").length;

    console.log("Number of divs: " + result);
}


