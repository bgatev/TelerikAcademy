﻿(function Main() {
    var booleanVariable = true;
        integerNumber = 2;
        stringVariable = "Hello Telerik";
        nullVariable = null;
        undefinedVariable = undefined;

    console.log(typeof(booleanVariable) + " Boolean: " + booleanVariable);
    console.log(typeof (integerNumber) + " Integer: " + integerNumber);
    console.log(typeof (stringVariable) + " String: " + stringVariable);
    console.log(typeof (nullVariable) + " Null: " + nullVariable);
    console.log(typeof (undefinedVariable) + " Undefined: " + undefinedVariable);

})();