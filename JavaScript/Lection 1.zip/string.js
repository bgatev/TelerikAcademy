﻿(function Main() {
    stringVariable = '"How you doin\'?", Joey said.';

    console.log("String: " + stringVariable);
})();