﻿function CalculateRectangleArea(rectangleWidth, rectangleHeight) {
    return rectangleWidth * rectangleHeight;
}

var width = 35;
    height = 2;

    console.log("Area is: " + CalculateRectangleArea(width,height));