define(['httpRequester', 'q'], function (httpRequester, q) {
    'use strict';

    var apiManager = (function () {
        function loginHandler(requestUrl, username, password) {
            //validation
            var url, data;

            url = requestUrl + '/Token';
            data = {
                grant_type: 'password',
                username: username,
                password: password
            };
            httpRequester.postJSON(url, data)
                .then(function (result) {
                    sessionStorage.setItem('authToken', result.access_token);
                    document.getElementById('info').innerHTML = result.access_token;
                    //window.location = '#/';
                }, function (error) {
                    document.getElementById('info').innerHTML = 'Error: ' + error.responseText;
                });
        }

        function registerHandler(requestUrl, email, password, confirmPassword) {
            //validation
            var authCode, url, data, header;

            url = requestUrl + '/api/Account/Register';
            data = {
                Email: email,
                Password: password,
                ConfirmPassword: confirmPassword
            };
            httpRequester.postJSON(url, data)
                .then(function (result) {
                    document.getElementById('info').innerHTML = 'Registration successful!';
                    window.location = '#/login';
                }, function (error) {
                    document.getElementById('info').innerHTML = 'Error: ' + error.responseJSON.message;
                });
        }

        function logoutUser(requestURL, sessionKey) {
            var key, url;

            url = requestURL + '/user';
            key = sessionKey;

            httpRequester.putJSON(url, sessionKey)
                .then(function (result) {
                    console.log('Logged out successfully!');
                }, function (error) {
                    console.log('Error: ' + error.responseJSON.message);
                });
        }

        function createPost(requestURL, title, content, sessionKey) {
            var url, data, headers, postTitle, postContent, key;

            url = requestURL + '/post';
            postTitle = title;
            postContent = content;
            data = {
                title: postTitle,
                body: postContent
            };
            key = sessionKey;
            headers = {
                'X-SessionKey': key
            };

            httpRequester.postJSON(url, data, headers)
                .then(function (result) {
                    console.log('Post successfully sent!');
                }, function (error) {
                    console.log('Error: ' + error.responseJSON.message);
                })
                .done();
        }

        function getPosts(requestURL, urlFilters) {
            var url, filters, deferred;

            deferred = q.defer();

            filters = urlFilters || '';
            url = requestURL + '/post' + urlFilters;

            httpRequester.getJSON(url)
                .then(function (result) {
                    deferred.resolve(result);
                }, function (error) {
                    deferred.reject(error);
                })
                .done();

            return deferred.promise;
        }


        return{
            login: loginHandler,
            register: registerHandler,
            logout: logoutUser,
            getPosts: getPosts,
            createPost: createPost
        };
    }());

    return apiManager;
});