define(['jquery', 'underscore', 'apiManager'], function ($, _, apiManager) {
    'use strict';

    var controller = (function () {
        var requestsURL;

        function setRequestsURL(url) {
            requestsURL = url;
        }

        function setDOMEvents() {
            $('#main-container').on('click', '#btn-view-posts', function () {
                window.location = '#/view-posts';
            });

            $('#main-container').on('click', '#btn-checkNumber', function () {
                window.location = '#/check-number';
            });

            $('#main-container').on('click', '#btn-login', function () {
                window.location = '#/login';
            });

            $('#main-container').on('click', '#btn-register', function () {
                window.location = '#/register';
            });

            $('#main-container').on('click', '#btn-request-login', function () {
                var username, password;
                username = $('#tb-username').val();
                password = $('#tb-password').val();
                apiManager.login(requestsURL, username, password);
            });

            $('#main-container').on('click', '#btn-request-register', function () {
                var username, password, confirmPassword;

                username = $('#tb-username').val();
                password = $('#tb-password').val();
                confirmPassword = $('#tb-confirmPassword').val();

                apiManager.register(requestsURL, username, password, confirmPassword);
            });

            $('#main-container').on('click', '#btn-logout', function () {
                var sessionKey;
                sessionKey = getSesionKey();
                apiManager.logout(requestsURL, sessionKey);
                clearSessionStorage();
                $(this).hide();
            });

            $('#main-container').on('click', '#btn-create-post', function () {
                window.location = '#/add-post';
            });

            $('#main-container').on('click', '#btn-submit-post', function () {
                var title, content, sessionKey;

                title = $('#tb-post-title').val();
                content = $('#tb-post-content').val();
                sessionKey = getSesionKey();
                apiManager.createPost(requestsURL, title, content, sessionKey);
                window.location = '#/view-posts';
            });

            $('#main-container').on('click', '#btn-get-all-posts', function () {
                var posts, source, template, html, $tempContainer, userFilter, patternFilter,
                    urlFilters, typeFilter, orderFilter, postsCount;

                //url filters for author and content of the posts
                urlFilters = '';
                userFilter = $('#tb-filter-name').val() || '';
                patternFilter = $('#tb-filter-pattern').val() || '';

                if (userFilter) {
                    urlFilters = '/?user=' + userFilter;
                    if (patternFilter) {
                        urlFilters += '&pattern=' + patternFilter;
                    }
                } else if (patternFilter) {
                    urlFilters = '/?pattern=' + patternFilter;
                }

                //sort checker logic
                if (($('#tb-sortby-type').val() === 'date') || ($('#tb-sortby-type').val() === 'title')) {
                    typeFilter = $('#tb-sortby-type').val();
                }

                orderFilter = $('#cb-descenging').prop('checked');

                //how many posts to show
                if ($('#tb-posts-count').val()) {
                    postsCount = parseInt($('#tb-posts-count').val());
                }

                $tempContainer = $('<ul>');
                source = $('#posts-template').html();
                template = Handlebars.compile(source);

                apiManager.getPosts(requestsURL, urlFilters)
                    .then(function (result) {
                        if (typeFilter) {
                            result = _.sortBy(result, function (post) {
                                return post[typeFilter];
                            });

                            if (orderFilter) {
                                result = result.reverse();
                            }
                        }

                        if (postsCount) {
                            result = _.first(result, postsCount);
                        }

                        _.each(result, function (post) {
                            html = template(post);
                            $($tempContainer).append(html);
                        });

                        $('#posts-container').html($tempContainer.html());
                    }, function (error) {
                        console.log('Error: ' + error.responseJSON.message);
                    })
                    .done();
            });
        }

        function isUserLogged() {
            if (sessionStorage.getItem('sessionKey') != undefined) {
                return true;
            }

            return false;
        }

        function getSesionKey() {
            return sessionStorage.getItem('sessionKey');
        }

        function clearSessionStorage() {
            sessionStorage.clear();
        }

        return {
            setRequestsURL: setRequestsURL,
            setDOMEvents: setDOMEvents,
            isUserLogged: isUserLogged
        };
    }());

    return controller;
});