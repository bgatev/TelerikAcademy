define(['jquery', 'controller'], function ($, controller) {
    'use strict';

    var uiHandler = (function () {
        function loadDefaultTemplate() {
            $('#main-container').load('templates/default-page.html', function () {
                if (!controller.isUserLogged()) {
                    $('#btn-logout').hide();
                }
            });
        }

        function loadPostsTemplate() {
            $('#main-container').load('templates/view-posts.html', function () {
                if (controller.isUserLogged()) {
                    $('<button>').attr('id', 'btn-create-post').text('Add post').prependTo('#main-container');
                }
            });
        }

        function loadLoginTemplate() {
            $('#main-container').load('templates/login.html');
        }

        function loadRegisterTemplate() {
            $('#main-container').load('templates/register.html');
        }

        function loadAddPostTemplate() {
            $('#main-container').load('templates/add-post.html');
        }

        function loadCheckNumberTemplate(){
            $('#main-container').load('templates/check-number.html');
        }

        return {
            loadDefaultTemplate: loadDefaultTemplate,
            loadPostsTemplate: loadPostsTemplate,
            loadLoginTemplate: loadLoginTemplate,
            loadRegisterTemplate: loadRegisterTemplate,
            loadAddPostTemplate: loadAddPostTemplate,
            loadCheckNumberTemplate: loadCheckNumberTemplate
        };
    }());

    return uiHandler;
});